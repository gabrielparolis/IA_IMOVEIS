package Trab;
//ctrl+shift+o faz imports automaticos
import java.io.FileReader;
import java.util.Random;

import weka.classifiers.lazy.IB1;
import weka.classifiers.lazy.IBk;
import weka.core.Instance;
import weka.core.Instances;

public class Avaliador {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		Instances imovelTreino;
		Instances imovelTeste;
		
		FileReader leitor = new FileReader("imoveis_weka.arff");
		Instances imovel = new Instances(leitor);
		imovel.setClassIndex(0); // define qual e o atributo classe
		
		imovel = imovel.resample(new Random());
		//System.out.println(imovel);
		
		IB1 vizinho = new IB1();
		IBk knn = new IBk(3); //k = 3
		
		imovelTreino = imovel.trainCV(3,0); // 1o parametro = em quantas partes vai dividir a base. 2o parametro = iteracao atual. 
		imovelTeste = imovel.testCV(3,0);
		//-------------------------
		//treinando os classificadores
		vizinho.buildClassifier(imovelTreino);
		knn.buildClassifier(imovelTreino);
		
		//-------------------------
		//gravando os resultados em um arquivo .csv
		System.out.println("real;vizinho;knn");
		
		for(int i=0;i<imovelTeste.numInstances();i++){
			Instance teste = imovelTeste.instance(i);
			System.out.print(teste.value(0)+";");
			teste.setClassMissing();
			double vizinhoValue = vizinho.classifyInstance(teste);
			double knnvalue = knn.classifyInstance(teste);
			System.out.println(vizinhoValue+";"+knnvalue);
		}
	}

}